abstract class AppStates {}

class AppInitialState extends AppStates{}

class App_Change_BottomNavigationBar_State extends AppStates{}

class App_create_DB_State extends AppStates{}

class App_insert_DB_State extends AppStates{}

class App_get_DB_State extends AppStates{}

class App_get_DB_Loding_State extends AppStates{}

class App_update_DB_State extends AppStates{}

class App_delete_DB_State extends AppStates{}

class App_changbuttonSheet_State extends AppStates{}