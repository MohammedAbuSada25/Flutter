package com.example.todo_project;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
