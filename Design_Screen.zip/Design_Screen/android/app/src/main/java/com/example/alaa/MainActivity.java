package com.example.alaa;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
