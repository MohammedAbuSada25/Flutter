const LOGIN = 'login';

const REGISTER ='register';

const UPDATE_PROFILE ='update-profile';

const HOME = 'home';

const PRODUCT_DETAILS = 'products/1';

const GET_CATEGORIES = 'categories';

const FAVORITES = 'favorites';

const CARTS = 'carts';

const PROFILE = 'profile';

const ADDRESS = 'addresses';

const ORDERS = 'orders';

const FAQS = 'faqs';

const CHANGE_PASSWORD = 'change-password';

const PRODUCTS_SEARCH = 'products/search';
