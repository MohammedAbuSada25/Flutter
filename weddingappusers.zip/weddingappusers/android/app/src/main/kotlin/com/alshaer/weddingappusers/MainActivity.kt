package com.alshaer.weddingappusers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
