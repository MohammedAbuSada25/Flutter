//
class hairdresse{
  var name;
  var price;
  var image;

  hairdresse(this.name, this.price, this.image);
}