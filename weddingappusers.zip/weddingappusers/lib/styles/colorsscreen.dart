import 'package:flutter/material.dart';

class WeddingColoer {
  static const Color benkycolo = Color(0xffffa3a6);
  static const Color textcolor = Color(0xff0c0901);
  static const Color buttoncoloer = Color(0xffde2929);
  static const Color bbackcoloer = Color(0xffcdbfc0);
  static const Color withcoloer = Color(0xffeadcdd);
  }