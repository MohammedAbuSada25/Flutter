class Sizes {
  Sizes._();

  static const double dimen_0 = 0;
  static const double dimen_1 = 1;
  static const double dimen_1_5 = 1.5;
  static const double dimen_2 = 2;
  static const double dimen_3 = 3;
  static const double dimen_4 = 4;
  static const double dimen_6 = 6;
  static const double dimen_7 = 7;

  static const double dimen_8 = 8;
  static const double dimen_10 = 10;
  static const double dimen_11 = 11;

  static const double dimen_12 = 12;
  static const double dimen_13 = 13;
  static const double dimen_14 = 14;
  static const double dimen_15 = 15;

  static const double dimen_16 = 16;
  static const double dimen_17 = 17;

  static const double dimen_18 = 18;
  static const double dimen_20 = 20;
  static const double dimen_21 = 21;

  static const double dimen_22 = 22;

  static const double dimen_24 = 24;
  static const double dimen_25 = 25;

  static const double dimen_26 = 26;

  static const double dimen_28 = 28;

  static const double dimen_29 = 29;
  static const double dimen_32 = 32;
  static const double dimen_33 = 33;
  static const double dimen_30 = 30;
  static const double dimen_35 = 35;

  static const double dimen_40 = 40;
  static const double dimen_42 = 42;
  static const double dimen_44 = 44;

  static const double dimen_48 = 48;
  static const double dimen_50 = 50;
  static const double dimen_55 = 55;

  static const double dimen_60 = 60;

  static const double dimen_80 = 80;
  static const double dimen_87 = 87;

  static const double dimen_100 = 100;
  static const double dimen_110 = 110;
  static const double dimen_120 = 120;

  static const double dimen_125 = 125;

  static const double dimen_140 = 140;
  static const double dimen_147 = 147;

  static const double dimen_149 = 149;

  static const double dimen_150 = 150;
  static const double dimen_157 = 157;

  static const double dimen_167 = 167;

  static const double dimen_200 = 200;
  static const double dimen_214 = 214;

  static const double dimen_230 = 230;
  static const double dimen_300 = 300;
}
