package com.example.foodlap;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
